<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '17d476e06898857a7378446a19cbc16d',
      'native_key' => 'core',
      'filename' => 'modNamespace/72f3281811f36a6837a76e77896a3c92.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'a1913882968976386e28ff243b597ea4',
      'native_key' => 1,
      'filename' => 'modWorkspace/0c78034d856525d9a143081dc5365487.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'e9714fd31ea3bf6ed67d247f40a073f0',
      'native_key' => 1,
      'filename' => 'modTransportProvider/5a987917c20489ba55fce39b783e2079.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7add2edb4e27273b21e2f03999d3cae7',
      'native_key' => 'topnav',
      'filename' => 'modMenu/dfb5cc06a7739f8fae573bae1e6b9d9a.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9dd2e7ef53230f45e01b1c0a8783587f',
      'native_key' => 'usernav',
      'filename' => 'modMenu/47f03f4da313cc4d4991bb32238fcee7.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '66a1b150ffd2cb6ba1317011070ca91c',
      'native_key' => 1,
      'filename' => 'modContentType/a4242468aee5dce2df420b5556ea9b0b.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e26e934f21266d2d858742f5f31d5a09',
      'native_key' => 2,
      'filename' => 'modContentType/f1ab6babc387b5058d8e32f3d8e70fa2.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ad1116f17bea8c8ba152604a21ad9707',
      'native_key' => 3,
      'filename' => 'modContentType/f7239a9b73fcddfd8d7a61b05b631acf.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '60c45f50936f4b5cf33c3a2361af2900',
      'native_key' => 4,
      'filename' => 'modContentType/229b0e3906ff4ef8b7712fa68a5ac953.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5cfddf73ca07df463f001d4eeae51fad',
      'native_key' => 5,
      'filename' => 'modContentType/b6f07542dea54e28f446a3bd389707eb.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '6abbe266360610225e12f67553c51736',
      'native_key' => 6,
      'filename' => 'modContentType/09631065492f641cece2cc82520c01ab.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '9d404544bf9ddbc77e8ad8926c7f201a',
      'native_key' => 7,
      'filename' => 'modContentType/15d2e979566e14bdc17eb585d415a875.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '40b654f6dabccefc4fc1cd5a96f5367a',
      'native_key' => 8,
      'filename' => 'modContentType/0e7eb360543e942e1f5c955cc68bec07.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '71a441afe66e6186675368f408bd7c7d',
      'native_key' => NULL,
      'filename' => 'modClassMap/35b1f8bb4cccb8cddffd13818c102b4c.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ff3fa99880495461e8c154911e06caee',
      'native_key' => NULL,
      'filename' => 'modClassMap/bd311a68d7d9edd1e8d861d8b919847d.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd6e5b7492b6665c286ca36a9e65acc36',
      'native_key' => NULL,
      'filename' => 'modClassMap/7bf45db68cc12810029c5b01fde7389e.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '381e408ede59916dc62e6ac84952937a',
      'native_key' => NULL,
      'filename' => 'modClassMap/ca81a313c09a1263d6db6f61749dc879.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2b3d9cf9eebed27212c8122cab00f6f8',
      'native_key' => NULL,
      'filename' => 'modClassMap/91433818537da64d7d8a2b1f10d17c3c.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '560f5927ed6d69aff5c4c7186b685d2b',
      'native_key' => NULL,
      'filename' => 'modClassMap/af4b897eb7fe31b18e0792cd8dc01d5d.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '85bc185cbaed4b5c2e9a63832b771d92',
      'native_key' => NULL,
      'filename' => 'modClassMap/83cad4712ee7f919f4ef3066d299d46d.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'eb9d59ff00345819e9afcde6d7e91547',
      'native_key' => NULL,
      'filename' => 'modClassMap/4726df48b2b0a9f648efc1dc01b2a8aa.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'af6be25dccb9d0035651e58682ca013a',
      'native_key' => NULL,
      'filename' => 'modClassMap/34f153df9609762a2bf1923d13fa0b5a.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a34ed77c8c3f2cea6be41d66601931e',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/faeb87ffd6d46f68c53c0dee04ed34e2.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '139896e366c57558e222dc6593e6c40b',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/6df2859542e56cdbe34760d8abfe5eb3.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6652194a9433e95dba429713a7bc36a1',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/257780588b9345b4aa8d0c051fec4ae0.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77c08b9e4027ad3c310e277e1b2a436c',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/27dd162312e2a8a532e71a9c16438ca2.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4e25bc2a34695f9a03cf746694dea1c',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/96cab3abebf1873561ea75be36377e3f.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '704d5e12afa98f87a8ff5dec56f4d6d1',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/83800666fb7e4c1ae0eaeb164974e482.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '614f299b74a1320b48545ba0bf90c7c4',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/63cd9264bfc1de8272f53396a7f2f176.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c69305e1a6128680fb739fc78e58110',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/c387d1707c58988cfb6ac23a443b90c6.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbeaded40b36e19b0481f284d5aa4c19',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/6cb0b8d1a6354ed51d19fdfb029225be.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31909a7663464728c7dde666e5b356f6',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/65bd21e35439f4d5a225843543dfd886.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c0126bd17dc9003b92710424a111eba',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/7d76df7603253a20498032dfb388eb6a.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fae311a70d8fb99c8d47995e1e2625f8',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/afd9fcefd17e57bd80145d1cdf69172b.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c07dd53ae41facfebcc182d57e58d928',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/04cceedecb7f04185c73280a76943010.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60caf5491fcbfa082c6c42df4f4a9c5b',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/26b2c1616badeea5ae5ecfde78e3a466.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63544acb9caa259ac3b7426ae35e9228',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/0001ad4caab52f5a3d87183aab095a4e.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9533cfb75d5030379f1acd90123fd52a',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/a3ab3a372b898e965d1fd396f8041af3.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f817543dd2af9ea3017ad664c60c53a3',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/2876ba637b2ea93e595c5374adb67fd5.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15a2b2bcb4bc685ae56255873297391f',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/7cf976c39794506ef79db2a810ec605a.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d30f04417d8f7cfc7a1a487ca151eab',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/fcf65957ef0ec7889c5926fc539b1900.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a50d4c1335ae6d7ba248233a6468d224',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/6447d20d80654b1190b1686671567550.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91ab2d8a6631377d3d4a65722fa110c7',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/e0e426ba42603240ba9b04d2bb4657df.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e4ab7e0ca25fe7053375d895588eea8',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/0f2a421755c704559b2d52d342ccf28e.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66ea97d9f00094dadd1220d9aef7e30a',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/761ea2ebef5c465ae0f558c6828bd585.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '096df5fb5a43a6b2af976a6648859f33',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/de830e91b9f24073d1db23d8d59a79d0.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b6af9e80720ae4b74a2550968bf9463',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/49456834f65475730a19fbfb5d9e25d8.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4c4b6cc9d6ea573d4b5c5584afc70ea',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/a1220c7bb53e338033fec0bb52a9e876.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37c6c10d89fc39feaeb56ed7a422b7a0',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/af2d4cff2f72ba8fb3160fcc9a21fd76.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5535fd674775ef1671296d07f15df25f',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/26b195ea38f76241426008ef0b2b005e.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4c916bc50ccebde905f61dbae6194dd',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/791507df0bd25e3799cf68a96a993cfe.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dedc7b331435a0f95f842d33f47dc88',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/256dd48066f0441bc20bd4ffb1c8d6c9.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e62af38e5d5eec83707d61278c9ead00',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/b8e26f10b2753b1850cb10c6ee11b9a4.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dfd5f4eef8e2d886f57ab8ac6f3d755',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/1018aff9eb7a9f8ccf8a546d879ec031.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bf4a225aeaa21ab4c209bf3e2609d6e',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/ffc47182f2dfba7cda9f9038358c8aa7.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ace49e376ef475d5b765ae081098a664',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/69e4192f19740a34a2ae75cf8582a129.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f3511fa6582d7b114be3e2361e90d37',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/2f0ee9f2f3ed12a0f0f91e48a062a061.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8661d7605b0095b37a037feded8c87f8',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/61cc112a2ebcab5bc4794ce0d28f95eb.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aaa32d070c8b914da1487f79ce90fad5',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/5b274ec0f8f7a31c1a3ed0ec6dc41473.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f158526b62ee2f9c743cadcc7bdd04a7',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/02c6e7daf040e92d9368812848066302.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b51d298caea04a85c32768fcdc9f532e',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/a57a1e0309a3d3815b0bb85948804f05.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff7b9ea736789b16f4089ad1bcc90d82',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/511c37946fad64279412f55a841a3998.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a731ce88bc43a24e9f6af146d3df65bd',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/e50d9a6f216617d11a265311fde98bd6.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '471e480b4c73d1c2e472c225695410a7',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/e0b5de452d6885f9604fd01343fe8f6f.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a56cb8cf820591cb7bf2d49fd322886d',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/5f6e4d7b0d0986fb43c3594eed42a502.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6aa5b708d0532860b5e5fda2de4ea633',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/c650fe58a43d6ddd8321af93e56401c9.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '995b41e6e85cef10c49dedf4e43099e2',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/90c7e253c1199514d8324f6cd7a48430.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0344cdda6280b5ee46f513777a933db',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/7dfe6f1ad995faa9a850971e0f31813c.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4f71eb23b8eca311cfcb0fda38d0b94',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/e7266459f94dcbc0586ae2b38481a25f.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cca8c22d164e831dc3b8e1b2fb4db714',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/21af277b6b2ac03362655f1d0430af82.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffba24d8c5acb84f168895ddeeb97828',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/73303304e529a88fd2a77da723fc6e9e.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eaee704993cfcb5c506d4331551ba0ce',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/49cbc3603a3c3665888ac502fcd078f8.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd20a72e7757cae4af08b426032e9a2c4',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/234c8fdef259b10b8aebbde01846e55c.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bbc7007e0ddd185ed30717772bec4db4',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/773e9b05e4a691d86a49636cfefc2e96.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f30f421a152c6e915eeb0aec6c8b4d3e',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/5f13fd105f371ad3fa60386ba6c69666.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02326c0582e9e6256ef464088720919e',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/5f02b110dc8657a885d690199610dec1.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62ccd478b8ff29e46e142edd7e9a2d1c',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/998087d525022bbd32b6ee8397232ae4.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80b608ec6f6e2e4376402db6ec2a551b',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/5b6327749ae08d549605ff1011518bde.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54b83989951cc2cdd16f038fbfd77b69',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/ff3c8850ba161dff55d0ddc76b6e8737.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a1c0f34ccc0cbce660c7b86ed72a337',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/cdf8eed922761e841fc5f3d2fa1bdd24.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4cc31b9e3c55d692f8dbd72cd1525c4',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/22de2ecbed9bd43d4a3847970e3a723e.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29ef2742ed385c4d78d8ee577995ddee',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/88503f874dbec1119431fd5a5d3c1dca.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8536af3ed8440c30191f2d486a9e3ff0',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/5de1a11ff28c6971f4237006880d3b58.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bcc14c5ddecd9c4b53990d6c34f4cd0',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/2653f17d982b6ad5c962f5385308603b.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b28008f76fb5546b0a17caf3a0f0e4af',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/859e897f9625d71daae0681af9da6ee0.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3dcd2984c90bd88b7294122d34ce2b29',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/611c4c85d34014df920481a50f5fc892.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36bc50245ef9c06fe0295234b2b13595',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/34f4b03c61c340c84c3361359e6b3744.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '004d084873df86e1185760caeab4922c',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/64bd699c9de921396ca6aa535b94ca26.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c00729aee8c9f7011ad94e3e567e1bc2',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/4fa531661b56be25ea7906a82989fc77.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22133baa2421ec40001661f6689e475b',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/f6753b943e933b37a60ab10066242906.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14a6926de2a74a4457e5f61e95b7f49f',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/300ab0f8d560052c9b7cedd9ba37f8c0.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '247ed9601ffae5d9102473461e48a9b0',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/e2ada0ebad06ad5bfcef5d9838a22f96.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bf4ef1f48d78fd6dbcf3175d04a7114',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/f6f7ab200d8af7ed13f494113ba5f7c2.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98dc48aad748c0f8f12098be8cca3829',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/09036035916bf4b42bdaaf8394eb1ef3.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa74a0d8e3845011a58f2390c5016020',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/f7bcb31ce14a5186f83031e024b46ffa.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7355d196ab14d9fb20800edbc2b9bda',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/609675dd20314025b439e5fcb35012cc.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '403d4ee332d3f6c3d089205aa800e4c5',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/c4ce2506c82c7d68825d59566f91884f.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6dc8eb002e53b8ae290891a375ab7784',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/ae153f8f0d61609ca87063b06cef4a0c.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52df73487a5a1ef758f785c3122a966d',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/c6b84724f189ec48b9ecc7890d72514b.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '133e519082ca510301f5662b794a24bf',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/dc34134f0eae7e1b4359899a436d488e.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec9ef5aea3e58bdc85ca32ad3a4f0e3e',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/0988f829803d97ab77e76593f0d888f5.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1880035907c3135f19f20cade1b4884c',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/b4b208447af41fb17ca8c716a346cc7f.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09203f631a1d4e4800a4d955d0fae1a4',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/80c45523fcdec92e832af75ca04a7325.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11dabe207feabaeff0e2716143c83f4f',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/17d2776630c91b38c7f820f015ac9205.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45411fed41f200baddc981b79d42ed5a',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/ed456a5fd3825b7a492a6c9c412fe1cd.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18a1ebc6bd14a1b6cff794a1d4bf6abe',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/8061f893707cd24b403345cab6fc1339.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10cbb8678f6363b049d6cf1f91ac286e',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/b5a0b47bd891e625470b05d8bdbb774c.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a711bd595c7c7124e7ab019f9f506c3',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/065dec493470615d651a028fafebbbfd.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce99368ac617793958644ad70971be0a',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/0f9eed5cc9c745dd899fdc4c443f79cd.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22c9ed822279a13599351e5052fb5651',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/7b539e838448cad328268dd9b5ea37d0.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e4acc3b3a3154b7e8d1b5d9d135a92c',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/8f81064ef3064332baf55a6c14fa7d6e.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc7d310b1038544bb355fc8ebbc94ae4',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/bece9a7359f1bc3adaaca1d782277c84.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b64a2c73fcc6797f1099136448dbf49',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/bc89c41961a2972817857d470ed2ddce.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a133db316dba7bfbbbb0affe169cc0d7',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/d03fc0aaafe23f0a60237a0b51fb4c23.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9dbd0234b9c90f0e6e55bcc0b65ade1',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/8defa4f470b0b1622ffb00c6045ad370.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9559eba1fd2f83bf9a44d554cfafceab',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/ff3c6e72693d241a317e06d5d7ef3f65.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c234a1c0c57c25e60bb0c1906e371223',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/8c2c3577d79e25e141fbbbfe08c035b7.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9812c58fe91bc3331eebf0a013a8c24',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/d9afeeee93c845bb8bc6ba775664b2af.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '360a87de9ef05ecc554d5d41e0421445',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/4d80cc957f50c5d94f63b32da68e8d75.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '947efe95008252ba86948d25f36d308c',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/a9d7a9fbbb32a962dad772fa934401fc.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb93e86caa3872a2b06e6ca8c0113372',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/bba7b52847d50e27d3d6810bfd868416.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d4e8f52cdba4b1c7351d70bd0db9b18',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/44621670cd0b25dccac5ca520f1ceab0.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f8fc61d97595407653e4ded9b1e0767',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/68a7c9d40936d259cbd388c3efc7fbde.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '832b37efdcf609b7690ddc70acde2069',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/3eb397cf1e550b9b096a6b5a0b83cfe5.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83613e4e42cea6791e1c45d396f7ad64',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/3378c1fffb0c1da0f0046131160a966b.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59ca841c61dffaf7840025a18631e869',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/b1a747794d62c069aabaf430c35827fd.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccd72ef6f7802b6a1625f5e0442273a3',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/991d17456037298d60984615f62b07a0.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20e2f2dbb27057963a5d42fcde812801',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/f7ff1b566a6ac7b9054286ccf9c306c1.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7f013e4abb27964f79ba5d9ec9270d8',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/30bd1845a11045126aaad2682ddc4e72.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32903eb70180ae906da1f76931af70cc',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/2127bdc162eafc69e9d518eb030e0124.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0936703883fead44cf7cf7513e0e8aad',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/7fdd45bde8e7708608b0fbfa9e336045.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9593e84cfcbe5a9999476adc9312ee11',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/5470b5f87f78a519cfba4c0532bf3da8.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac11cc5b4790ae6271d0cff59a396c5d',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/2f671a59e46d97907dbd05abc82b9e86.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27f9d4c7c64068e118460973ced1eaf8',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/8ccb2ee5aba7506e9a9d55854e9aed10.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '076381b075ae15c8c130aaf6c4d1383a',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/2e2323a7b80da6a97d9e6b5f195a5499.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80126e0dde68594c3509e0b542f2ffe3',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/ebac28b14b74ff6831f70dd504ca597c.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83488e53e740fc62a7a02e3311dcb488',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/b782053f0929ab12a4a2be09915f2e94.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '413f592ed179114c40ac9c7b9ea4203e',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/95604af3312e23f3b7e20927ecca77a9.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '369f27a888c622e8b72f913dc2af8030',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/e652d8fe1ab0701cc17080bfca1ad59f.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5823ccf138ce36dd1a2bec386a7fb069',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/5d095a0c654f3a3a74e65dc6ca27e3b2.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7edf4db242f8c2af906428d1aa461aea',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/290ee64741dc30852284548fbd8d73ca.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b7a65605ffc16f1c793d7c12fc26f7a9',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/15a75a4e543daf4222b18f96828a1292.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf4d61185cbea8273e51bcf1fe10be18',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/6a8370d120551f74932ea7097dd155b8.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a7a0f5456f9936da165d8e448b6d5df',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/4e66362d99378271f121d9ccdb52483d.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54ed5e312c7926e0e7bae3a057060327',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/106d42f58f2e57275f296802c520609b.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd193d979c18bf4114ccf578a260f636d',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/292db9ec5f4834d8daae372409275e88.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bba2a3f1c67af3fb635462c8fbb726f9',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/c57b1665df72e596e2a7155c31f23777.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e92190f1595c541fc17dc7fc8679304c',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/225b6f6df0607d1ff228e3b5192af45d.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd51b716e05ac9955ed52c8a8eba21d5b',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/3e29bbe841ef862b4c9efb86df7b4b0d.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '772fc7e8eb6a70a4afb219bdfc1b36c5',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/63295180e525e16bef00be42732a62f2.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8ee96028105acbaa397f8562cbbe257',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/270f096e5c34dda598227fa625e4b134.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76834ffb8a568368539614985552e3f6',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/4955ac8b2ce3f3609b36811bfb3c5d78.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a2e0e8a117fcacd08b2d472201f118f',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/fbc29a334fbe118d2aa9255629e3e32a.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1529cd697e100c1bef67a27f65cb95d',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/2f07a30944e301f1990c31c0ac5db4b2.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fa62eea692775708e711de3472da6c6',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/baf543fa561298ece70daf1a89421eec.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd56804c54d18a21e7e471f70f8cd656d',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/1d3b3ca1972ec00774d19d5b903c8ca3.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e30bcee081bfbe84a60e053bd75cb7b4',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/67de5318107f4b21ec8ef42f16556b53.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bfec5e5c6a7fac36a9f4eeab51dd79a',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/720053504af15c99ac58e84652ec512b.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62854e30ac1ed3a8cd171dd86b150d6b',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/6b0ea9943774b81dcefa5e8b96dd71a9.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56279013c4aadb4241367313a0a35443',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/d72850fe86e2d7892245017d57ac7382.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2afd434ee7863d3fdbda2e79c9cce47e',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/23417ef395f0e855f3e1369203cd66b2.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8987896644de1050334c0bc1759a0c9',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/ee9a8b0006d88aef88983d851b21f57d.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73b222ed6c02a3be473835e997509587',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/eae85e1b69508fc4a5c079025cfd9956.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0185055d883d81b0faf4e3af3fab9999',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/0b4085309e232b9d8b9e01e18dc0ae8b.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a530c59fe09078d2cc24c6c525b8340f',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/1ba71ac1ea51fb49601bf54a1468b707.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '258f1d569482fe75e935f4e6e4f0b5e1',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/16d2819b7efdd2416f7f41d15eb2ba50.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab0e22e6a45d3207d4722eff9cf68f15',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/46f9bfb854ca566cd1d39a2d0c5ab196.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd23392fe261290c24a3c28a0becd9e33',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/1003514242446a94c984127169499e7b.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3283d4ed9e2208eeec1ba07bacbaa97c',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/f1e8b2bd99ea4199129b7d878282b460.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd33b4b72274c057bb0473e567b0858e3',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/2878117bbb5c9e7dd576c4da264e4a73.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff247d4c1844869f31ce25738d7f7903',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/13f4fab3ea9b753047de95404725eda7.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '827d8e0941cac944eb2ab6a7703cf925',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/ed38f848abfef521a6428e7073bb372d.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf8cc25b2fab92a323aae38b82a10625',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/1a5d83044c0d1d546cd08ca687e8b3f4.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd12307e7ddb6485d15582596ab1880d7',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/70e41c2857303bb24b90f6247c18ea6e.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af7bcceb8c3321ff0f094e19b065d76c',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/007c318880145ca718d983079c298fdb.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '716364500856a9a66dc9825305c02d22',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/ffdcef31127926c1c7bc0fb8c6d14a9a.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '919595b3fec88f350174257a2d7cbc78',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/ccde74d9ff2950401224bef00d8e6205.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b5253d72b5452936e0844fc7e731118',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/4494f47ba802aa2cc19855f3285c05db.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19aa1d390ecc27852b4a8406bb630851',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/a295d5e0e8804b9395507f025087470a.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ceb0de22e3c27361a5b93369ea5ae762',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/61079883d55c353ffaf9c6ecbc10e8dd.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74091cc9e910f83658551f5cecc9e69d',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/6785df5b105c75d6c64b0ff94db8da5d.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '437a05690a02680b3a3729e0bab6e3f3',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/4c87edf4c9e8d73489d53890c4c72b41.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5689ef5f976cf27d9ff9edfe66b864ae',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/a6d4f299a6cd970c4ef671e2e263cb4b.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '251cdbfe6c46477363a64d12abcc40b5',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/1acb264a61be4a7fd01476fe1df8f9a1.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '688a58d5ea46b571181bd514311b67d5',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/bbc02a2afed031fffe345c7ecfd7bebf.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ec6fd9fab4da0e8a0b8609fce817d58',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/c414b020a19ff32db231f75ad6aa65e1.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b14c35eee04f1f877dbb3712d70612ba',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/ad70b4f17aed1c4e81aa73913da0708e.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf46a69d43e245db1fa4b1043bed327d',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/da367971fc7d2d8184461468645422f8.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4e16590368ad13e1f9c959fe1386e7e',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/47c5839fdb1c168118307e6f38d0012d.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4da61dc6cf66a97486e387d186a05aba',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/2290eb63db90a0c30ed610300d3c91b5.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c207c7e019a1dcdd9eff8a6249d2713',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/77fb57e3bd5ad01b11d9d96c0812ad4a.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ede702d1442dbb436f1c6178adfd243',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/57f4e7e7468367e8061ca4308b2bc843.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e39afe7cb4b9078412007e67702c962e',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/baed6fa223cb31ace8a0d5ff1d3a6667.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65115250ab5be96597be76f07ca588fc',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/717235368be3c67dc28dfe421e531e81.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '715af9c1052b314c53aaaef28553c9a5',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/411c954f66c945d4ce114cddb2f798cf.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd700e0c019251f024ff7affe468f0b8',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/f7ea929603fcb774aaffd30a738cdf27.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '421634546be36e33564d757336291d35',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/382e3223fdb1c6aa645303fd6b62bf81.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22db42e88a2fc60db40e82540dfd309c',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/8a3edfa0edada61e0db49ea0b0bd91e7.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29bbe4c9bc388a327d60cfeb998d0804',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/46e20eae3b31e6c1004307c6c74829b5.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f89653db7a5457f703bc4af7a9975cb',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/e3361dc6e5bdd500b1c708cb63effc04.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e20ebbdd6f54de4608827b6f48f2b06',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/2a8cdb59e58c677637804fad9a505c88.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16214df88ca18dd70ceac33673f4814b',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/2a016da7efad9533e2f18cf2065161d5.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4670ad2f6deed5f8cc72133ec6951108',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/52f3c2c1f98f6fe1374bed1227b1b48f.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c8f701279f28ec67d9a41d5a0842a98',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/6e2d45099f7c4522b62eba88c38c1951.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '216138ff756ec061b1a3a6d1c80ae7d7',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/b0e2c7e1b68bee34481d1a59c3e27e2a.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d19cce8686d4974de35da0364610856',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/aa15a63bfcc10c8fb1a1abd7558b3aa5.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecf91c7fee8233770d845e9b1111cc6a',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/4372c64eaa646bc27281d673577ee86a.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c7f056df0112ea355b139ee2e2dabbc',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/8e9e78d1be257ebcd3517e96e296fcaa.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c7dd2a45c7517652a4e18b9d9c199c4',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/4f379e292e32fbac081b61f9180e7c9a.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2c625d8c9882a832d2fa6ea5db925e4',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/38c67336a55f534115f1b9dfb2474b17.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3c6fb8cba1b7d961742782d20250de0',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/66db531027c9901c28a7d480fb455614.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79171b6274b8ab806d4683f4e47d9677',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/439245cec00510432aa6a5f48ef21342.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb72bf8b1c35689245859d0807ffd5e9',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/f396402d83306b9429e1b14388448a3e.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6e4f3c5e9b1735742586db2cd94999c',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/d541c946d8984718aed448216d1e08be.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61c729e5503a8d081477a0edf97a4199',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/671aacfd47073c64dabb3d253f055d6d.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ad28622dac883cdd96e088945800f83',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/767918bb4dc64bbfaf86053afaa7d7e7.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '871913e0621af79a134611cd05b11a33',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/a5484e53c11fbe75946032b2b8af6450.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e15df3134f51441873ac5b6ab3b79e7',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/9828de30dc9c1f9a22fa3c604294d5d4.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55e1f54b23b00efed86608d1fb07f05b',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/ddba56615f4deb1bd15b296f96b7a213.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc7004162e26a48a10603dc6e68b7785',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/991351de8e7cfcdd09ef1dc3ddaa1d9f.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '539e23306dd894c1391055c5826a24d5',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/d3ff373cc60229754122c6fc75f1eccb.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa6f9f284ecccb04f09d748a08711289',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/d8e6f1e689b990780849b25b8ba1feab.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48f1dd1e3d98577ed11c3795c1357f48',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/9704018cf4547f57001da86a8b8cf81c.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aab35b48d122f38777b4da26fc247196',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/f5959037131c8a1063a1e57d42d07c6f.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a54fa705ea63a7d0b71fb4503bd43531',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/01c30fe6b36e216a196edd98d1ee11aa.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53df8ff083316985f2b5045d05111a98',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/b7c35717d77b0050784eaef694080ca9.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b872a5dd826d9807da1000b99f3b4b04',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/d9d3419fe1c00c2c890982a960021d26.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dc910cb27466608618c55068864448e',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/99b155550bb5d66b2f28fedbecd80385.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e49676f0b20e06cfa312bdd15fbdac99',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/8440d5501de2fadc296c8d25f849db36.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f02ff9644513ec504f48e821567a3581',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/2631bbb099a0da147d13daeeb61b5fae.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44cfde90f74e8a36d69d6a26e0636fd7',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/f74accfb256fc42266f286573b7fb47b.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bca5e42858afdc883734f262a46ebac0',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/53b3f10e202ddb8d9b8baa6425396f0a.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ab55b4e153e07afd7a2dbb2638fa1a9',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/49691d01aa28215715461fe7004a802a.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfbe9af7a4588cf2743ac3280c70c07a',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/c9d7ebb7c7ba0772fdd1edc73b752bb4.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '203df638ea4b1924b34f8387b39d9791',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/d359c830fcdc51971a4c4b9cc9db6e53.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd962aef2e29afc7aa6fdaa77cd4af6a0',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/08c41b408fcc8e6acf7200f7e7b553e6.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd010d85698c1ee030fd2eef579b5bb1',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/8fbfadffc0b8f5af8519bd1b78440a6d.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f7da8985e8a837466ac6cf722fdf07d',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/35cf35b50b518f0dd3222d59f722f076.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75938377f0a66a0d5c0e684ed40b6dcc',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/e2a104c57ebbf4e5af9afc1154e1fe0d.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7128d6735897223dd4510c1d753ddc3',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/e75dc18a2f2950594363f5093d885864.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99ca7bb601030d6a7ff740980eb6e768',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/004099c6cd49d5ea6f994f4d1a7f3be0.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbfeb2f766a0eeda386b3a8a16a039f6',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/cb4841267a3046386c606b8ece5f51b4.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5790585ef984f4d5212b7df3cd3d582',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/37ca582891d35cd43c00063a4943242f.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8464cc802094e1dcbbe54dd767ee6b39',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/05c1da1c116f91d1330db5e8a4f5ab1d.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b13540613eaca26708d90337136bd03',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/d0d16d5bd4f798d5e268c1bcccb41ae2.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b249e486c87ee3cf322dc0d5eda7e32',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/5d61f15abd1a70380f1f75eb3f0096f9.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cfa6094809847bb82cc7da7819670a8',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/273ab5083d8baae2f31900737d88e544.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fed7d76e9049878053be0b287b246a6',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/9e9a097eedb2a532f23a5e81b3675d3f.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afa27157975b9372bdbdeeb198012c30',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/be0d55b45c52e86e141bf2184da493af.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36c815345f50df1ec06b05649e3bffb7',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/07afcc6e02c4c8bd0c30a9135e7e5355.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '636c239e52779f39b68813424d1ebfe8',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/37dd6d5f32d156feb197fb5d0f6d4d2d.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35c079b1ece80eef9a450565feee1278',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/024ae6efdb0ad22061c2aa11242bbcfb.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c679c29f0a2bbedcc05095d6e5a98c88',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/21ca650c97ade18c2cf22ebecc61dfb7.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf176a1378bec5411c0eb2270b0c417',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/3cdacde9a2d3d9249ff3dd5c15a9709e.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '243499d9a5d07f8779712feef235b455',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/142d52350230a76a3785fd8defc1be91.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c68c0ba33107659ebe677a4a4862e35',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/8e29a247a9b2bcb3e14d018ca8324e41.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e708c8f5d3276d31641e5428735cbd02',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/15ca6bfd2a9b366f8e31e2809b76c2ec.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c23d1ee284e70f3bf8ede51a2ee46125',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/07f82c548f5dd92f40e880e2b1b261b3.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31e6367f403f9b8c40205ef3c9017a11',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/ed8064211351d84449d40f537f30789d.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1173ec7fec6afdb09bfcc0563ef7a241',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/be4f51fdc5dc5d965e3d4af14f045e0b.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b524093a1c1925997d6310c5a66936be',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/022195de8104aaabfdb09006ecc8e37a.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '694c63d7afbb8bebfdf5b450aca4b33c',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/923b78880a8318db61968129980098a3.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6b41646d8f6cabf0545234f90e953a7',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/8a2fe1b957be92ceb148b2fad4489943.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd36d5a31d92106dbfe433420b473735b',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/e349fb94b73c8f33391eed25bf261d8d.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faf02c2b616a8a41ffacc36774240d02',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/63cf5c6eb7472a5af20f4805d2e519c3.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d87689306c3556518099de5ec8eea59',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/ac772a8cc78cf5f3a261c445d7b4da24.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2562de7735a5f2473727828f45b6108c',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/3411ee990d408d9c70f907604fb27e5c.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ab9736e41b10a0cbb086afcb3e6ba90',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/dbd53d5425ff0f2c8622e8222264c368.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e86c80851c5b33c11cc1da2a1ae8a294',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/e75d33bd0772305503aa1209e402761d.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65a8e05c5f024337c599d78a2ecfc1ba',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/1e3a35a8e41ed06ff43a82adcf69b6c1.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e576c52bc8e9c6bf63676682efe88b0f',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/6299d96fd1264df1973fa70feaee4e5d.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea7a58e71ffce33d26d09b8cf6dd6ad5',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/66a7f83a8922ecf4cf02c09a81056494.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74ff30304d77ec471f4e336ec46ef720',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/b90177252e87e7ec87c4c9acda656916.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eaa03b098932eafa0fac403cda31bb63',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/68e62b74232c706e5a2ae83e15f5fc93.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eaceeed0d98ba31583b7eb0ff5187c3',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/16b9324954f0f1eb5fa68d2029b1a9d5.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b399c22a6a53fcd6fc0fabf546c443c4',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/6560b11b15085410d79668e5228fd3d9.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e614f3443109b7bbf7fa347cc67e635',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/65e897039104254cca0fceaa6da9d3ff.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57f5b251f72cdd204fa38ef23c69528f',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/313ed66f3d158b45dbd22fa8113c8e8e.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b25937daf68b0203f3d92e3026281248',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/d53469edc22efef0d2f5b306105a748b.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01bebdf78a905d96b783fdd54bbc4ee5',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/589a630b4c93a2b90c70cfe29f53a5bf.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3337688315f2e0478deeb0aa25b437b5',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/d785e28a885795069ebba9025548159e.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0f569a9810fbdfcca2adf9ad8cffb3c',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/1daf6b76193563449590fbd0d2f0ed83.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc606bfcc952a10680fd8670672ab3f9',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/238e7b4a28140944690ccb817c0599de.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5f1b84fe3fd2c96ec3b910c5b2e5dfb',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/10311a396262e31d90720945d1a2c22c.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a73ff0bb9853af8ad74501186659c699',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/8292abfae40af190e3293ca20a7ef272.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab8851345b1a98b67774acbcf595d438',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/375ea65bd56e9ebeecbf62b4e4799eb4.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b1e35ee98527cd06960429da3e03bf7',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/5e43bb89f1b9ede0640d9c826a8856e1.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fad660c13ab28a0d9bfe342087f74c9',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/d59543919b5d48716970c6a49f015dd0.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd8ccc126000b4b79bd6824e3bf15c68',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/5cbfe0f3d674eb0ce53f27a88eb2d3e7.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d005263a4a5d4c05d54160f726fcf74',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/acc754aeda8b19ecbd6791ec076c0527.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82cd4609b2bc84058a17f11fb82a223f',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/26f0d89e0510db1fe344cecb9f349efd.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7755351e3c19141d98f75306ac0d8c65',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/056d41114882c2c86c9fc3092a7e4d86.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5343c38e486ddac424380217da1f57d4',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/32b0af40faed1216fc44c3e1108af382.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0877171abe04b28c65996f759e4e4d91',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/c702b8f1ac426b239c13b497db54b3f8.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64d19078b22d7bb7f39ca3b2a3955e56',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/d77bb2d1384302f2d35776405a2742d0.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eca6ca58b146e8f75616af1edf57ca33',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/07093fd35394a70fbb19e275462cee1a.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '347c828ef493ef38dbdb5073dbcaabdf',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/f38c3764d561068cfafbde92366e4e3a.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c74ad6f05d376576859b8023d95fa9b',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/279e7f42af710703926b560a470d74d4.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffd844cffcc0c00f2572f9e4bcf7498a',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/601c54608cc9563571799d7a2e2b2667.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '270a2e6ad0d75c967efa3751becb034b',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/176124ba36340c3dac9fb699c1c77b38.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '994056553c4db299b5c42e3fed862dc3',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/22465de680defa9aec4044c5263f86ad.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0cbb73a1636fcb7144c1aebe9d30fc9',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/c72d1d8071882341f0b530ec69f0c701.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a51b9c1c8c1786f166a3ff0fd1db1cd5',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/c0c91e4e2d590987ff0a1b06ffcb8daf.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e982609e063dc15a7323aad1c805a202',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/ed8e9ba0bb6529ac24ce4f2e0305a2c7.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93070bc6ac754f77b98219c60fd611fb',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/aa6210f0317c6750142d5eb84c080a09.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39c238c4bafa8732506809658922689b',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/b1252b988ad9033d03e835ed09935b5f.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b29c3c96f70c37b65cfbae0094ab3804',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/e4894b40d310285c9de3d868a6265053.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9811574de0144098d9fb3271b79bcbd2',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/8556f913e42bbef67fc6352739d1dbc7.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e4a42440cc0f7dc6ef650951c3e8b6f',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/1541504ee84aa0dcb3f5d1e81bbdb03d.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab6f6f22993180438aa69565a4f4b595',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/c85951067bf867aa48f72d70df4232cc.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '433d944b00f72e48e9621d0659541ad9',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/514fbcf3a9d51d212294346594898fbb.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '627392d70dcde58e4796fc5a8be844b7',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/308b6dfbc9b9bedf6440103fc69f3456.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be36ee68f32d2765cf8008fdebcb2fe7',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/38949c7805996c670cec8f864b55bfc7.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10e5d37a37050ac4f807ab1be8ab8503',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/a3d788fd18eaebfaed29c17a39f8d7f0.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68aced340c584a44dc02372405efaaae',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/4928822dfd33410eb593870612bb8825.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '178b06343611a0ce48c4d43f0cd5bfb3',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/01f08884085c7f7579938468f0b5f5cb.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a36d2a38035334064d3eb9f4fff202f3',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/bdfb8bc4a6df76da9a3f8811060f034e.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c494e7c5e97f33bbf268593f597fff7',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/944d47783fba28bf9c4e98bf64f33c85.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea509958debdf24b3dc75ef0fa2a119e',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/433318672b356a153d0fe85cb78d7147.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b1ec4f5a045f6d1cd0d5ac4de7dc857',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/ba0aa941873d92ce0944ea223124f3f3.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e8d9ce28669b4996223e5e7bff0bb7b',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/07022fdb2bd58cd852a5d07ced9bf9e3.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '924f1a111d5b57196f4a694493e93489',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/67985014092ba6276d6d49e84c8d2552.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ccb772989d48dabb357fc5746f3afc5',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/931a49ca240c73a109f3c5cbcf5cdfa2.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b45a9ab38960971c00c08ccb9633bf5',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/ba396874379a54a924f1305db568aa4c.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97f0dc106f45eaaf736c6e9a06b91477',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/61570c82f21870c8593766c39df6a3b2.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a78e9db9a606915497918ef42aac99a',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/5bba17710c27147d3aea83a011846ac6.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3c5a95f3a05f0b1649962bc8bee4493',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/9d50f193b7250bbf99f7975211e92d3d.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07c4dcb7d6e695f5b50b41590219f9d6',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/de909459d650b9753f33a68f51c510c4.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15fd43d1ef8b415b24bd0cac032df65c',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/0cd5c8d62c225ea5bff61c8365040f84.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea496c510c4880f8567b6ca57444960b',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/87c7fc1444c10ce77ced38935a452f1f.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13fcf5d32932e2c6786d24fb687aeecd',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/517818dd0154508a1e287e50c8a7213b.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24b03a9644920dac54080125297d24c5',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5b56c0cf72d7df589ce26e3080310ebc.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35522c7bf4c9c54b6d70b8d2a5795c19',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/ca90a7a6173d8adda36690833224fce4.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e11e127948ced172f3a68a0838751e9d',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/48f469bb2ebf2c5872804c499f1a12f3.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cf67bf7b13f56a3a3f09160eb8746f8',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/ab2fb16e7d1a56ec52c743f75f054e62.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '023a94a2b254e75678b4fd0e36b951b5',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/96beaeaa981eaad05d2a58a6fd2fdbb4.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae3f880962b6cae6221beeb233905d3d',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/f089c1acf057b68a19a61634d2397704.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f068e1c7e17787c5913c0ccbdedca389',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/1d5e51c867d248973d5f04924f4f4bc4.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '534c37866e545943672f28f772bd1936',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/cbf4ec9c89927535dab9ec7559465ba6.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0cbf8309bf2c5ff8c6df8df2d2000da',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/a847e052700093d11746257fec312c98.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14e85cf3a3fb3f8633ff0b837f37ca87',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/bd8a2fa580d4fa84b73a7f0c1e0c2426.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '881a5492fcc63fa82694d319a484223a',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/db3c66042b858fb65e42adb0418eace7.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf975bdf687451d676534bed36884ea7',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/2081390dd15ffcf61f7c25ce77c5ce49.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a781d2bc19f229835b4679d1c0c14391',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/1bd95f40c30e5242e0dfcaabc0f0d92f.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c1cfcaec2e66c2e4c850641f7ced243',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/4ce2ffbf585d05e84150d8f8bea79f11.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '594048ea5c40ae1fc6e1718b4f166fdb',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/fa41a44199ecd2b1150c419d2cc525c2.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57a6862e42bd8dcdf8c1b61bf80f8574',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/937c4c78842e02e1767c2394f297f4ff.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e0805ca031c815be9be65001d0df3b1',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/b296b3d722e5844147c8e7adcd8ec010.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8177cbdf5923b5a4d8f078b58c7c6490',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/c10c02698f219185c2695367f8a78d1e.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5d38deedb770dfa7e5e5d00f9d2f4cd',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/1b17bae604817a71891bb3c46762b3e9.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c6a67922b7e626ece8f4b97b69fb505',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/f0ea19160053a0dbc24685078fa5188d.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c83827d6b3abe3e10db1ef826efd558f',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/c19a828ab84333692a60bb905d987991.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7c3242ac7a0bc6d59bab52bdc10279f',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/45ec3cdb451e7d63511f3231e80e8ef6.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5dd73ac04c7e89a6d12fa7ae08ea86b',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/409d6e96c05579c8d5b015063bac2b1b.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9d44e881d5c87c6ede3e8b19715730d',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/fbfde006b59a67ba13e028b708029511.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31e6cf1f605b7d527e7e4bc56dbd6ab0',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/c97f84b0f866fef639ae4a051426aa37.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39e9c3d8edcf205d54ac8e99e0d99727',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/5219ec9547867610246fed64093cd10c.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a59e8d33001187cdb5fc144f5ae85f74',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/46d6546955317bb8068653a1a5e49719.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e190959a8f88375053f9af05cc81e1ba',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/e801bbff3fd26a8466360ae2f199fd83.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6097f966b1d8a1416ee212ebf10c50b4',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/c1868ee4ba68b62b4289ed9fa272707e.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8187668c65dbd751dbe598282bc09c58',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/f2a5a5e88632dea708f76bc00321ee5d.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0080f216247f640c81461bb952525e4',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/96a8a33a5be2e896fe0a758f93f9a603.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f549f45b008a31be82735bbb4d1e2d82',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/2dfbde23916c377c6aadfec615e25c8f.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '347d36cbea03bf3a9cc7b1c129e18061',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/0212f951e8da0e2e514bac8ea7d6b462.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63166ecd89b21bcd1fa03a47fcbd2ce6',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/f5d991f14af156be9aaa6fe5c2976f85.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f562f6884475b53a5a464a205e150095',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/c06f96e78bcc4c99f3e814ab5b061239.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eed17d02fdc1e43cf3f2d8c47ac54e73',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/cf953234012879a7ab425ebbd842025e.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab533713788840abc8457553daf366b5',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/fc68472e9269a5f3f2f9c53337a67713.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91d51b53b58e14485cf146971d9233ab',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/697e4de9ff4c989bad306291c405f51d.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd84b26a19e286cf2f7bcc248f53e15c6',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/5d9cc05855c490d1ba926c9c40874b08.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d9873a9962b040c379f8a96caef244e',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/7f1643cf27a74b90a70792bf48d4d4eb.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dd39e2674f4232d90337dfd0bc7daaf',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/2f5836fe006a4fb2f6b7b79125cfe48c.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79da5374916af73ca7bc656b9af550da',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/d2e3e29079d06cb56a3e0b195d1e6b7b.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddfef30fe4264cd415d3ab82a72ba358',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/044f49176e0be5881065f8d211674944.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18010d56dd9858cb6ee80d4c560624eb',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/f6f3b7c9f0b30cf09c8dbaa545439b8a.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b22bf2d0a7470e332a0060f19e52e84',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/5a80f05ac3eaf4b2f5496fa15da70ce5.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '759f083852d69190116151ca5f124bf6',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/51cc8943713c41ffb58ebe5454b2b415.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40de839025d08d8723fb8f7fc344ea88',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/3dbb0dee3a0d8acd137f4a0c23f87c5f.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '727ef877aecc552e8e2bcd2428861cab',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/6d0908c02340bde2ffb5a78f2cea3c35.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c108e98abbb07c6960d15a5d9eb783f',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/6521aaf0142053d75dd12e1fac5e345f.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ccbf8ecefa34fe3a19a4e4aab56ebe9',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/0c55eb750707dd9efc2e70f41f8fa764.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '220b8c754c22d83803749b7542920a60',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/4469226ac4a93990100db2ff99170d93.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '909f3a2a042601663c9d79019351139d',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/b94069c474ce3e3802c1a8b800f70f95.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ca5939130e267f463f13bcba2667d00',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/d54e3771f0fab5342f3bfcd449b073ca.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '671e466f98b6a2902c453a308ae5eacb',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/a1fdb79f778f581ec4bf2ade39db385a.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd98658555d1e143f135d1bb4757f8cb4',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/ce1a369682466946d465982e3625d0ce.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0049adf098594a76bff2d54f566229d',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/c8c64d4ee66fded24b5ae04fe5466979.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3187e6d6a57ce601555446e74023158c',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/01649600681aee6567351075f9e145ff.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8635d79818949119ca79c40d7f331e1f',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/7cc1d91e3d7c0f0311085c6baafc7d62.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3848bef034835d7b767f20e0e3cd312c',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/73d1d780929d886e6b7f6c83bad2315e.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '649f735758bbd529e93eef5738bd7826',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/954bbee22659748a06879b2dff780d69.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a97c9120a0a9569f0535ee8ec575100',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/c78cf1bf8bebf5aed8c232e4d4c63c8f.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c7ce0409d932657ef6a2d0ed68fca34',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/582b59a637b6afa1de4a48dbee6a48da.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dca3291cd3ab99984bfc999cc89ea0f',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/1e28e27c053a20f6ddd8234bc8aea7df.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0b4eb99c64bf9ca3d695306ae434f48',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/f3fa24f9e589444785d4937384e0022d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '320ea428d79eb689ff5393a34e2e5a4c',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/07ce17d7e81177fd7dd08cac8ee84257.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4268819183a26185058bb568a6afd777',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/ddb238d2de3b56a3827e47bd3215651f.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14450666a6e9cc077cebd46e6f26504d',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/27f536d356ec865da3660e5f3a36eadc.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc7709f6ad64c58ff14526fc4b21d6e2',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/859b9c321472fc1bab62c1784a5e5268.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f6954ba3d5c24f726de1710f85a5d9c',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/17266ec5567ea9a8aa01e47c4300be54.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d17bd5813a9e6a9b4fd651c1091bf26',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/985afa670f208a0d9776784c84a70649.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df9020fcd7846aec93fff333ff8a4b2c',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/09f37ef4c1b960932caa1a45c8c09d46.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8d9c9a06ce5e9a84872236e357faa83',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/4d8e3f019eb6d44aaba17f919cbb749d.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50285c4f67564d2c617da0fe4da019e6',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/70fe9f421fa5ba9c62b655acb2351e31.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3eed191418dba9eba1be695a3aeac2ac',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/b47480f8df4c2ffdd88c380104216a23.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b73ce9eeeb658397013691a88ee6d109',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/1ff4c1f2b6f08880d3eef51a026618f9.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9336a09677fe16623e6e26eb0822e4a9',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/248d99d54f0f596821bd4e860ae7c420.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff6477b3aef46897201d82ab2a810f3e',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/d77ac2c3157abff38ead67edd52d93de.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6689a9ae2e8ffc9a55cd253a504e7839',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/0c9a2f2ff51f037e142f8fbfaa427fca.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0b4b3c1cb1f74a559b37fba717bd54a',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/160690d261b82fedbd5268e100cf3405.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7d1eb75ffeddbe6a8d359c52342edb0',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/858d342a107d9a80319add9233abc694.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e2d2170046516e000630276695270bd',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/c84015a2681f85175e415bc9daa612b7.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88da7de7c93d807713e579e1ddbad4b7',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/45eb960e055169eb013af6439270e5db.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2defed8f61851e566076aebee30afb8',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/c288d105a3d21fb30cb69fe075015306.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f866486528633650b488027d87806f86',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/2264ea75621219f8211ef9bd5363b070.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2361a83aeea7f462abf09850e029ffee',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/dad8e396fefbf9b132960858d0866bdc.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88fa5941e5c698395134adfbea81bc47',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/55bb6c791ad495f4d6cfb547afa5fb8a.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfe9997695ae25526590c9db555b53c6',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/15f0099a1dbd6d2787de55ca732fd964.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0af7327aa608390c44a47eecdd84c23',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/ccaf940329ca001eb81c05da9e439296.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e8bcdc190b4f0b4a0a137c789a8322b',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/0421d7a31fbb6b8c46b60a7239a0e355.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5bcf340d952b5711d9b7e7397f91437',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/9c1f7db35594ece16649d744e9a23742.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '105c29195ce408b05554d3b1b945e36b',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/96e7847334369cbfbe89f4472c0b4c5e.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0c3071585458476d087d5fb89eeabd1',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/2ca1487a388b4d61f8e2ccd4756c0aea.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16b2a1ddaad168e16587a74f803fb4e9',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/5342d64221e0047dfb3d432e94ea234d.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd399121f86a717c876f9dcae89c1f7b2',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/87dff29cf4261c75bd11c042ba8db861.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cd40cff266dcd86f0328e438157ef91',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/a67a4f086b3bb45ceaf1748927f8a59a.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '94de9964f721f5b791b8a4a717ac1a83',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/3cc2066eef74ac31c08669f1800ecdb9.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2ff737a6afdffcd6ec59874ccaa94ec5',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/5a5a541aae0028fb6df0a38f7f3bb4cc.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '5ee366ca4045a3ce69e675581476b3c8',
      'native_key' => 1,
      'filename' => 'modUserGroup/b8dd46e5c3670dd7701055ae363699d9.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '86592ad33b2ab0b31f7126d19e8e29ea',
      'native_key' => 1,
      'filename' => 'modDashboard/79ef7b0100a6d45629a25dffbcb1fc89.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '37a561ad27f9108db70e1b5caf129861',
      'native_key' => 1,
      'filename' => 'modMediaSource/e3e66a0131d2897bdac9e8774d5aaed1.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e038bcdcf30a9070dacbd2e81472ab12',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b1d33d5193be3e24494e3be33536d3c1.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f0d07a0e9e8a01dbeaf3e52f11897a9b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/86ca0e93a617fcfc24eede76257b7d12.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '3be9e4c468485ef59f64853936230551',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/7bae18c9cd21a51b5ee06d62e02c3b1d.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '01c7d4e1a02887227b16beba5d0c4caa',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/5285b8c2c84caa73975cecf9cae728e6.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '151496ba0af2f08c8902a4d863cd27ed',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b51d75772ce1e304e90966e07433085d.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'db52a92be6fe6331e515e560d54b2f4c',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/1010ebda686045c1f0603ac88608d04d.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'b913d95ea1cde0d423a9f0edb0dbefc0',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/d562337875a111de8b4a892fe1b356f2.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ce5b51dbd8ba4b20fffa6c29af22c054',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/abbb6eef05ca15af4e9a497cf4a45af9.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4403f92e0ed5d921defd01d46ba6b27c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/bca10db53f74113761ecb72f25dd3c0c.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '1f1f91d99532e062e50cb7d01e0f6949',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2932467f5e0b467d317b27701db5c37f.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e72432431d0be414600f48975576f34f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/f95f65942da6644613038d5be1c96443.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '2ba8125d869a39dde1b873366bc44b2d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b246dae9dcdafbab4dda69a42b5f34d1.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7e19c466b97e16805c8e222d48625390',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1c11f5811a5323d97a490a3d591dc761.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5966ab9eb6ef9bd35643dd2a5e1533dc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/c46bb3f9cf4b7e3a9b34b3ecb747126a.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '948ea60848f9afb7fad697f9694e587d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1ca4204794fd2b4a23e5981a5e733a87.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '602d244624e747cc64673c4858291a5d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f2113f9001107902f0790248f2526edd.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3973ec63b22634cf9650cd89292dc735',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/144aeb12d74d13b8eada3ca3ecc76ece.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9d485c7789ef8fd4e36ef4aed97da796',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/edcd447b6c0334d3b7f7a46e6674c2af.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '125f0cc91c7bc26a84cd45a41f9db4f8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/272962fcffba3272f0c50fa184f837be.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0fb63a2b60740d3e15ef8f9a5e03a727',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/95afdd28d923024a6b931154ceb39a97.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '55495bc1c306e79ea5f7bacf08f4c3d2',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/64eb32d4f06bd66fdee2d7ab9333d8df.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dff710438350d1af902f7edbe9fe3e12',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/ef241cf02fc535aaf01cd7333cb5d7a7.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1bed04c49cdf69a9726c000c760af6c1',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/1ba6803d2ed7c844853af78ddc7afeb3.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '34ab12c77e0579c33f1e68a350b18234',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/c1ebf8bbea535857460a3c21b2ec33d8.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '98174ef4fe6d72351f563034cca1ed04',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/492ed9bdd85b565167e8bf4d649fb19f.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ad1dbe462be6a184524d4e610fe65fdf',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/7f2e484720992d714f01e9777067f39f.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a2bb4be9fae4c8ff50af406a33c6f066',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/e3eae070afa5a20e8681e1141307feb9.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '75c57fda54812eb96470177ebcd41b6f',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/09ef5ac35c3db97cc0b81fbb3a669f78.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c278249d4a5fa8a1ee3c4de5ca250d7c',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/09e920603152471469ffdce680342c76.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '80a86039aa2eb8702a753bc873f9308b',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/1892473753d71173851ea16b3b889aef.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '879543b6b9ca45d98729383e6a4b6a53',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/ad0038666ee7b44485bba14bcc6af594.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6ecf50c904bac92c85d2c0986431142d',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/5046d3c6ab5a7e37bf82ac3096c479f3.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '44c8d73bf7980887758f3b9fb8430cab',
      'native_key' => 'web',
      'filename' => 'modContext/ac4121c595e6140dbfc6c106e6fe1c55.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'fa12468b63814e2f6326a08c082396f0',
      'native_key' => 'mgr',
      'filename' => 'modContext/a4c22c8a918ea424285f06a58194b065.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'dbd7965b68c15c212e22288550b9bba4',
      'native_key' => 'dbd7965b68c15c212e22288550b9bba4',
      'filename' => 'xPDOFileVehicle/e31dfddaa3e6859278422b5172f654a3.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c6c31bfe918d79d6a0b949ce231e745f',
      'native_key' => 'c6c31bfe918d79d6a0b949ce231e745f',
      'filename' => 'xPDOFileVehicle/78cf7126821220c0f974cd169544452f.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '31980ef548cf9fcc8cde3f326dd870bd',
      'native_key' => '31980ef548cf9fcc8cde3f326dd870bd',
      'filename' => 'xPDOFileVehicle/cd2004d9f13a8c54ca2d7d9b522aea55.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '95185d93155d378a74aa8d8041c53dfe',
      'native_key' => '95185d93155d378a74aa8d8041c53dfe',
      'filename' => 'xPDOFileVehicle/3bd0a8c1fd96422476a9457266db68f8.vehicle',
    ),
  ),
);